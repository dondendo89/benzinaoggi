importScripts('https://cdn.onesignal.com/sdks/OneSignalSDKWorker.js');

// OneSignal Service Worker
// This is a minimal service worker for OneSignal compatibility
// The actual OneSignal functionality is handled by the SDK

importScripts('https://cdn.onesignal.com/sdks/OneSignalSDKWorker.js');