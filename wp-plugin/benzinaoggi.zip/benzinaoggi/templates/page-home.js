(function(){
  'use strict';
  
  // Configurazione
  const config = {
    apiBase: window.BenzinaOggi?.apiBase || '',
    mapCenter: [41.8719, 12.5674],
    defaultZoom: 6,
    pageSize: 50  // Aumenta per mostrare più distributori sulla mappa
  };

  // Elementi DOM
  const elements = {
    locationInput: document.getElementById('bo-location'),
    fuelSelect: document.getElementById('bo-fuel'),
    radiusSelect: document.getElementById('bo-radius'),
    searchBtn: document.getElementById('bo-search-btn'),
    myLocationBtn: document.getElementById('bo-my-location'),
    map: null,
    resultsList: document.getElementById('bo-results'),
    resultsCount: document.getElementById('bo-results-count'),
    markers: []
  };

  // Stato applicazione
  let state = {
    userLocation: null,
    searchResults: [],
    currentFilters: {
      location: '',
      fuel: '',
      radius: 10
    },
    pagination: {
      currentPage: 1,
      totalPages: 1,
      totalResults: 0,
      pageSize: config.pageSize
    }
  };

  // Inizializzazione
  function init() {
    // Controlla se l'elemento contenitore della mappa è presente prima di tentare l'inizializzazione
    if (document.getElementById('bo_map')) {
      initMap();
    } else {
      console.warn('Contenitore mappa #bo_map non trovato. L\'applicazione funzionerà in modalità lista.');
    }
    bindEvents();
    loadInitialData();
  }

  // Inizializza mappa
  function initMap() {
    // Controlla se la mappa è già stata inizializzata (più robusto)
    const mapElement = document.getElementById('bo_map');
    if (elements.map || (mapElement && mapElement.classList.contains('leaflet-container'))) {
      console.log('Mappa già inizializzata, skip');
      return;
    }
    
    try {
      elements.map = L.map('bo_map').setView(config.mapCenter, config.defaultZoom);
      
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(elements.map);

      // Controlli mappa
      L.control.zoom({ position: 'bottomright' }).addTo(elements.map);
    } catch (error) {
      console.warn('Errore nell\'inizializzazione della mappa:', error);
      // Fallback: se la mappa fallisce, imposta su null per evitare chiamate successive
      elements.map = null; 
    }
  }

  // Eventi
  function bindEvents() {
    elements.searchBtn?.addEventListener('click', handleSearch);
    elements.myLocationBtn?.addEventListener('click', handleMyLocation);
    elements.locationInput?.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') handleSearch();
    });
    // Pulisci geolocalizzazione quando l'utente inizia a digitare
    elements.locationInput?.addEventListener('input', (e) => {
      const value = e.target.value.trim();
      // Solo se il valore digitato non è vuoto e non è 'La mia posizione'
      if (value && value !== 'La mia posizione') {
        console.log('User is typing, clearing geolocation state');
        state.userLocation = null;
      }
    });
    elements.fuelSelect?.addEventListener('change', handleSearch);
    elements.radiusSelect?.addEventListener('change', handleSearch);

    // Autocomplete città (Nominatim)
    initCityAutocomplete();
  }

  // Debounce helper
  function debounce(fn, wait){
    let t; return function(){ const ctx=this, args=arguments; clearTimeout(t); t=setTimeout(function(){ fn.apply(ctx, args); }, wait||200); };
  }

  // Autocomplete con Nominatim (OSM)
  function initCityAutocomplete(){
    if (!elements.locationInput) return;
    
    // Controlla che il parent esista per l'autocomplete
    const parent = document.querySelector('.bo-location-input-group');
    if (!parent) {
      console.warn('.bo-location-input-group non trovato per l\'autocomplete.');
      return;
    }

    // Crea dropdown
    let list = document.createElement('div');
    list.id = 'bo-ac-list';
    list.style.position = 'absolute';
    list.style.top = '100%';
    list.style.left = '0';
    list.style.right = '0';
    list.style.zIndex = '1000';
    list.style.background = 'black';
    list.style.border = '1px solid #e1e5e9';
    list.style.borderTop = 'none';
    list.style.borderRadius = '0 0 8px 8px';
    list.style.boxShadow = '0 10px 20px rgba(0,0,0,0.08)';
    list.style.display = 'none';

    parent.appendChild(list);

    const updateList = (items) => {
      if (!items || items.length === 0) { list.style.display = 'none'; list.innerHTML=''; return; }
      list.innerHTML = '';
      items.slice(0, 8).forEach((it) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.style.display = 'block';
        btn.style.width = '100%';
        btn.style.textAlign = 'left';
        btn.style.background = '#2c5aa0';
        btn.style.border = 'none';
        btn.style.padding = '10px 12px';
        btn.style.cursor = 'pointer';
        btn.style.borderTop = '1px solid #f1f5f9';
        btn.addEventListener('mouseover', function(){ this.style.background='#2c5aa0'; });
        btn.addEventListener('mouseout', function(){ this.style.background='#2c5aa0'; });

        // Migliorata logica per etichetta più pulita
        const name = it.address?.city || it.address?.town || it.address?.village || it.name;
        let label = name || it.display_name || '';

        // Tenta di pulire l'etichetta se è troppo lunga e generica
        if (label.length > 50) {
           const parts = label.split(',');
           label = parts.slice(0, Math.min(parts.length, 3)).join(', ').trim();
        }

        btn.textContent = label;
        btn.addEventListener('click', function(){
          elements.locationInput.value = label;
          // Centra mappa usando le coordinate del suggerimento
          var lat = parseFloat(it.lat), lon = parseFloat(it.lon);
          if (!isNaN(lat) && !isNaN(lon)) {
            // Salva come posizione dell'utente solo per centering, la ricerca userà la stringa di testo
            state.userLocation = { lat: lat, lng: lon }; 
            try { if (elements.map) { elements.map.setView([lat, lon], 12); } } catch(_e){}
          } else {
            state.userLocation = null;
          }
          // Salva scelta in localStorage
          try {
            const saved = JSON.parse(localStorage.getItem('bo_last_search')||'{}');
            saved.location = label; saved.userLocation = state.userLocation; localStorage.setItem('bo_last_search', JSON.stringify(saved));
          } catch(_){ }
          list.style.display='none';
          handleSearch();
        });
        list.appendChild(btn);
      });
      list.style.display = 'block';
    };

    const fetchSuggestions = debounce(async function(){
      try {
        const q = elements.locationInput.value.trim();
        if (!q || q === 'La mia posizione' || q.length < 2) { list.style.display='none'; list.innerHTML=''; return; }
        const url = 'https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&limit=5&countrycodes=it&q=' + encodeURIComponent(q);
        const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
        const data = await res.json();
        updateList(Array.isArray(data) ? data : []);
      } catch(_) {
        list.style.display='none';
      }
    }, 250);

    elements.locationInput.addEventListener('input', fetchSuggestions);
    document.addEventListener('click', function(e){
      if (!list.contains(e.target) && e.target !== elements.locationInput) { list.style.display='none'; }
    });
  }

  // Geolocalizzazione
  function handleMyLocation() {
    if (!navigator.geolocation) {
      alert('Geolocalizzazione non supportata dal browser');
      return;
    }

    elements.myLocationBtn.disabled = true;
    elements.myLocationBtn.innerHTML = `
      <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
      </svg>
      <span style="font-size: 12px;">Ricerca...</span>
    `;

    // Helper function to reset button state
    function resetButton() {
      elements.myLocationBtn.disabled = false;
      elements.myLocationBtn.innerHTML = `
        <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
        </svg>
      `;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        state.userLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        
        console.log('Posizione ottenuta:', state.userLocation);
        
        // Centra la mappa sulla posizione dell'utente
        if (elements.map) {
          elements.map.setView([state.userLocation.lat, state.userLocation.lng], 13);
        }
        
        // Aggiorna i filtri per ricerca basata su coordinate
        state.currentFilters.location = 'La mia posizione'; // Flag che indica l'uso della geolocalizzazione
        elements.locationInput.value = 'La mia posizione';
        
        // Cerca distributori vicini
        handleSearch();
        
        // Reset button state
        resetButton();
      },
      (error) => {
        console.error('Errore geolocalizzazione:', error);
        let errorMessage = 'Impossibile ottenere la posizione.';
        
        switch(error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Permesso di geolocalizzazione negato. Abilita la posizione nelle impostazioni del browser.';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Posizione non disponibile.';
            break;
          case error.TIMEOUT:
            errorMessage = 'Timeout nella richiesta di posizione.';
            break;
        }
        
        alert(errorMessage);
        
        // Reset button state
        resetButton();
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 300000
      }
    );
  }

  // Ricerca
  function handleSearch() {
    const location = elements.locationInput?.value.trim() || '';
    const fuel = elements.fuelSelect?.value || '';
    const radius = parseInt(elements.radiusSelect?.value) || 100;

    // Se l'utente ha digitato qualcosa e non è 'La mia posizione', resetta la geolocalizzazione
    if (location && location !== 'La mia posizione') {
      console.log('User typed city name, clearing userLocation:', location);
      state.userLocation = null;
    }

    state.currentFilters = { location, fuel, radius };
    state.pagination.currentPage = 1; // Reset alla prima pagina

    // Persisti l'ultima ricerca
    try {
      const payload = {
        location: state.currentFilters.location,
        fuel: state.currentFilters.fuel,
        radius: state.currentFilters.radius,
        userLocation: state.userLocation // {lat,lng} oppure null
      };
      localStorage.setItem('bo_last_search', JSON.stringify(payload));
    } catch(_) {}

    // Blocco ricerca se mancano dati essenziali
    if (!location && !state.userLocation) {
      alert('Inserisci una località o usa "La mia posizione"');
      return;
    }
    
    // Se la location è 'La mia posizione' ma state.userLocation è null, avvisa.
    if (location === 'La mia posizione' && !state.userLocation) {
        alert('Per usare "La mia posizione", devi prima consentire la geolocalizzazione cliccando sull\'icona 📍.');
        return;
    }

    searchDistributors();
  }

  // Cerca distributori
  async function searchDistributors() {
    try {
      showLoading(true);
      
      const params = new URLSearchParams({
        limit: state.pagination.pageSize,
        page: state.pagination.currentPage
      });

      // Logica per determinare se usare coordinate o nome città
      if (state.currentFilters.location === 'La mia posizione' && state.userLocation) {
        // Ricerca per coordinate (Geolocalizzazione)
        params.append('lat', state.userLocation.lat);
        params.append('lon', state.userLocation.lng);
        params.append('radiusKm', state.currentFilters.radius);
        console.log('Ricerca con coordinate:', state.userLocation, 'raggio:', state.currentFilters.radius);
      } else if (state.currentFilters.location && state.currentFilters.location !== 'La mia posizione') {
        // Ricerca per città (testo inserito dall'utente o dall'autocomplete)
        params.append('city', state.currentFilters.location);
        console.log('Ricerca per città:', state.currentFilters.location);
      } else {
        // Condizione in cui non ci sono filtri validi, ma il blocco handleSearch dovrebbe già aver bloccato qui.
        console.warn('Filtri di ricerca non validi. Interrompo.');
        showLoading(false);
        return;
      }

      if (state.currentFilters.fuel) {
        params.append('fuel', state.currentFilters.fuel);
      }

      // Controlla se la cache è disabilitata
      if (window.BenzinaOggi && window.BenzinaOggi.disableApiCache) {
        params.append('nocache', '1');
        console.log('Cache API disabilitata nelle impostazioni');
      }

      const apiUrl = `${config.apiBase}/api/distributors?${params}`;
      console.log('Chiamata API:', apiUrl);
      
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error(`Errore HTTP: ${response.status}`);
      }
      const data = await response.json();
      
      console.log('Risposta API:', data);

      if (data.ok) {
        let distributors = data.distributors || [];
        
        // Ordina per distanza se disponibile, altrimenti per ID
        distributors.sort((a, b) => {
          if (a.distance != null && b.distance != null) {
            return a.distance - b.distance;
          }
          return (a.impiantoId || 0) - (b.impiantoId || 0);
        });
        
        // Aggiorna stato paginazione
        state.searchResults = distributors;
        state.pagination.totalResults = data.total || distributors.length;
        state.pagination.totalPages = data.totalPages || Math.ceil(state.pagination.totalResults / state.pagination.pageSize);
        
        updateResults();
        updateMap();
      } else {
        throw new Error(data.error || 'Errore nella ricerca (API non ok)');
      }
    } catch (error) {
      console.error('Errore ricerca:', error);
      alert('Errore durante la ricerca: ' + error.message);
      state.searchResults = []; // Pulisci risultati in caso di errore
      updateResults(); // Aggiorna per mostrare il messaggio "Nessun risultato"
    } finally {
      showLoading(false);
    }
  }

  // Aggiorna risultati
  function updateResults() {
    if (!elements.resultsList || !elements.resultsCount) return;

    const count = state.searchResults.length;
    const totalResults = state.pagination.totalResults;
    const currentPage = state.pagination.currentPage;
    const totalPages = state.pagination.totalPages;
    
    // Aggiorna conteggio
    if (totalResults > 0) {
        elements.resultsCount.textContent = `${totalResults} risultati trovati. Pagina ${currentPage} di ${totalPages}.`;
    } else {
        elements.resultsCount.textContent = `0 risultati.`;
    }


    if (count === 0) {
      elements.resultsList.innerHTML = `
        <div class="bo-no-results">
          <h3>Nessun distributore trovato</h3>
          <p>Prova a modificare i filtri di ricerca o ad ampliare il raggio.</p>
        </div>
      `;
      // Assicura che il footer della mappa si adatti
      updateMapWrapperPadding(48);
      return;
    }

    const itemsHtml = state.searchResults.map(distributor => {
      // Filtra prezzi non validi o con prezzo 0 (anche se l'API dovrebbe fare questo)
      const validPrices = (distributor.prices || []).filter(p => p.price > 0); 
      
      const prices = validPrices.map(price => `
        <div class="bo-price-item">
          <div class="bo-price-label">${price.fuelType}</div>
          <div class="bo-price-value">€${price.price.toFixed(3)}</div>
          ${price.isSelfService ? '<div class="bo-price-service">Self</div>' : ''}
        </div>
      `).join('');

      const distance = distributor.distance ? 
        `<div class="bo-result-distance">${distributor.distance.toFixed(1)} km</div>` : '';

      // Fallback per bandiera
      const brand = distributor.bandiera || 'Distributore Generico';

      return `
        <div class="bo-result-item" 
             data-impianto="${distributor.impiantoId}"
             data-bandiera="${brand}"
             data-comune="${distributor.comune || ''}">
          <div class="bo-result-header">
            <div class="bo-result-brand">${brand}</div>
            ${distance}
          </div>
          <div class="bo-result-address">${distributor.indirizzo || ''}${distributor.comune ? ', ' + distributor.comune : ''}</div>
          <div class="bo-result-prices">${prices}</div>
        </div>
      `;
    }).join('');

    // Controlli paginazione
    const canPrev = currentPage > 1;
    const canNext = currentPage < totalPages;
    const pagerHtml = `
      <div class="bo-pager" style="display:flex;gap:8px;align-items:center;justify-content:center;margin:16px 0;">
        <button id="bo-prev" ${canPrev ? '' : 'disabled'} style="padding:6px 10px;cursor:${canPrev ? 'pointer' : 'not-allowed'};opacity:${canPrev ? '1' : '.6'};">← Precedente</button>
        <span style="font-size:12px;opacity:.8">Pagina ${currentPage} di ${totalPages}</span>
        <button id="bo-next" ${canNext ? '' : 'disabled'} style="padding:6px 10px;cursor:${canNext ? 'pointer' : 'not-allowed'};opacity:${canNext ? '1' : '.6'};">Successiva →</button>
      </div>`;

    elements.resultsList.innerHTML = itemsHtml + pagerHtml;

    // Eventi click sui risultati
    elements.resultsList.querySelectorAll('.bo-result-item').forEach(item => {
      item.addEventListener('click', () => {
        const impiantoId = item.dataset.impianto;
        const bandiera = item.dataset.bandiera || 'Distributore';
        const comune = item.dataset.comune || '';
        
        if (impiantoId) {
          // Crea lo slug nel formato {BANDIERA}-{COMUNE}-{IMPIANTO_ID}
          const pageSlug = `${bandiera}-${comune}-${impiantoId}`.toLowerCase()
            .replace(/\s+/g, '-')
            .replace(/[^a-z0-9-]/g, '');
          
          // Usa il nuovo formato di URL (rimosso /distributore/ per usare lo slug base)
          window.location.href = `/${pageSlug}/`;
        }
      });
    });

    // Eventi paginazione
    document.getElementById('bo-prev')?.addEventListener('click', () => {
      if (state.pagination.currentPage > 1) {
        state.pagination.currentPage -= 1;
        searchDistributors();
      }
    });
    document.getElementById('bo-next')?.addEventListener('click', () => {
      if (state.pagination.currentPage < state.pagination.totalPages) {
        state.pagination.currentPage += 1;
        searchDistributors();
      }
    });
    
    // Assicura spazio per footer
    updateMapWrapperPadding();
  }
  
  // Helper per padding del wrapper
  function updateMapWrapperPadding(fallback = 0) {
     try {
      const wrap = document.querySelector('.benzinaoggi-wrap');
      // Calcola l'altezza necessaria per visualizzare la lista senza sovrapposizione del footer
      const listHeight = elements.resultsList ? elements.resultsList.scrollHeight : 0;
      const padding = fallback > 0 ? fallback : Math.min(Math.max(listHeight * 0.05, 16), 64);
      if (wrap) {
        wrap.style.paddingBottom = padding + 'px';
      }
    } catch(_) {}
  }


  // Aggiorna mappa
  function updateMap() {
    if (!elements.map) return; // Non procedere se la mappa non è stata inizializzata

    // Rimuovi marker esistenti
    elements.markers.forEach(marker => elements.map.removeLayer(marker));
    elements.markers = [];

    if (state.searchResults.length === 0) {
        // Se non ci sono risultati, centra sulla posizione utente o al centro della mappa
        const target = state.userLocation ? [state.userLocation.lat, state.userLocation.lng] : config.mapCenter;
        elements.map.setView(target, state.userLocation ? 12 : config.defaultZoom);
        return;
    }

    // Aggiungi marker per ogni distributore
    const bounds = L.latLngBounds();
    
    state.searchResults.forEach(distributor => {
      const latNum = distributor.latitudine != null ? parseFloat(distributor.latitudine) : NaN;
      const lonNum = distributor.longitudine != null ? parseFloat(distributor.longitudine) : NaN;
      if (!isNaN(latNum) && !isNaN(lonNum)) {
        const marker = L.marker([latNum, lonNum])
          .addTo(elements.map);
        
        const validPrices = (distributor.prices || []).filter(p => p.price > 0);
        const prices = validPrices
          .map(p => `${p.fuelType}: €${p.price.toFixed(3)}${p.isSelfService ? ' (Self)' : ''}`)
          .join('<br>');
          
        const bandiera = (distributor.bandiera || 'Distributore');
        const comune = (distributor.comune || '').toString();
        
        // Creazione dello slug più robusta
        const slug = `${bandiera}-${comune}-${distributor.impiantoId}`
          .toLowerCase()
          .replace(/[^a-z0-9\s-]/g, '') // Rimuove caratteri non validi ma mantiene spazi e trattini
          .replace(/\s+/g, '-') // Sostituisce spazi con trattini
          .replace(/-+/g, '-'); // Rimuove trattini multipli
          
        const pageUrl = `/${slug}/`;
        
        marker.bindPopup(`
          <div style="min-width:220px">
            <strong>${bandiera}</strong><br>
            ${distributor.indirizzo || ''}${comune ? ', ' + comune : ''}<br>
            ${prices ? ('<div style=\"margin-top:6px;font-size:12px;\">' + prices + '</div>') : ''}
            <div style="margin-top:8px">
              <a href="${pageUrl}" style="display:inline-block;background:#2c5aa0;color:#fff;padding:6px 10px;border-radius:6px;text-decoration:none">Vai al distributore</a>
            </div>
          </div>
        `);
        
        elements.markers.push(marker);
        bounds.extend([latNum, lonNum]);
      }
    });

    // Centra mappa sui risultati
    if (elements.markers.length > 0) {
      elements.map.fitBounds(bounds, { padding: [40, 40] }); // Aggiunto padding per migliore visualizzazione
    }
  }

  // Carica dati iniziali
  function loadInitialData() {
    // Prova a ripristinare l'ultima ricerca
    try {
      const raw = localStorage.getItem('bo_last_search');
      if (raw) {
        const last = JSON.parse(raw);
        if (last && typeof last === 'object' && last.location) {
          if (elements.locationInput && typeof last.location === 'string') {
            elements.locationInput.value = last.location;
          }
          if (elements.fuelSelect && typeof last.fuel === 'string') {
            elements.fuelSelect.value = last.fuel;
          }
          if (elements.radiusSelect && (typeof last.radius === 'number' || typeof last.radius === 'string')) {
            elements.radiusSelect.value = String(last.radius || 10);
          }
          state.userLocation = last.userLocation && typeof last.userLocation === 'object' ? last.userLocation : null;
          state.currentFilters = {
            location: elements.locationInput?.value.trim() || '',
            fuel: elements.fuelSelect?.value || '',
            radius: parseInt(elements.radiusSelect?.value) || 10
          };
          // Centra la mappa sulla posizione dell'ultima ricerca se disponibile
          if (state.userLocation && elements.map) {
              elements.map.setView([state.userLocation.lat, state.userLocation.lng], 12);
          }
          // Avvia subito la ricerca ripristinata
          searchDistributors();
          return;
        }
      }
    } catch(_) {}

    // Fallback: mostra messaggio e proponi geolocalizzazione
    console.log('Applicazione caricata. Proponi geolocalizzazione.');
    if (elements.resultsList) {
      elements.resultsList.innerHTML = `
        <div class="bo-welcome-message">
          <h3>Benvenuto in BenzinaOggi!</h3>
          <p>Clicca il pulsante <strong>📍</strong> accanto al campo "Dove" per trovare i distributori più vicini a te.</p>
          <p>Oppure inserisci manualmente una città o indirizzo.</p>
        </div>
      `;
      updateMapWrapperPadding(48);
    }
    // Avvia la richiesta di geolocalizzazione automatica dopo un breve ritardo
    setTimeout(requestLocationAndSearch, 1000);
  }

  // Richiesta automatica della geolocalizzazione con notifica
  function requestLocationAndSearch() {
    if (!navigator.geolocation || !document.body) {
      console.log('Geolocation non supportata o body non pronto.');
      return;
    }
    
    // Verifica se l'utente ha precedentemente negato
    try {
      var locationDenied = localStorage.getItem('bo_location_denied');
      if (locationDenied === 'true') {
        console.log('User previously denied location access, skipping auto request.');
        return;
      }
    } catch(e) {}
    
    // Crea e mostra il popup di richiesta posizione
    var locationMsg = document.createElement('div');
    locationMsg.className = 'bo-location-request';
    locationMsg.innerHTML = '<div class="bo-location-content">' +
      '<div class="bo-location-icon">📍</div>' +
      '<div class="bo-location-text">Richiesta posizione...</div>' +
      '<div class="bo-location-subtext">Trovare i distributori più vicini a te</div>' +
      '<button class="bo-location-skip">Salta</button>' +
      '</div>';
      
    // Aggiungi stili inline e animazione
    locationMsg.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #fff;
      border: 2px solid #0ea5e9;
      border-radius: 12px;
      padding: 16px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 1000;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 280px;
      animation: slideIn 0.3s ease-out;
    `;
    
    // Aggiungi stili CSS e animazione (riorganizzati)
    if (!document.querySelector('#bo-location-styles')) {
      var style = document.createElement('style');
      style.id = 'bo-location-styles';
      style.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        .bo-location-content { text-align: center; }
        .bo-location-icon { font-size: 24px; margin-bottom: 8px; }
        .bo-location-text { font-weight: 600; color: #0ea5e9; margin-bottom: 4px; }
        .bo-location-subtext { font-size: 12px; color: #666; margin-bottom: 8px; }
        .bo-location-skip {
          background: #f3f4f6; border: 1px solid #d1d5db; border-radius: 6px;
          padding: 4px 12px; font-size: 11px; color: #6b7280; cursor: pointer;
          transition: all 0.2s;
        }
        .bo-location-skip:hover { background: #e5e7eb; color: #374151; }
      `;
      document.head.appendChild(style);
    }
    
    document.body.appendChild(locationMsg);
    
    // Funzione per rimuovere l'alert con animazione
    const removeLocationMsg = (delay = 0) => {
        setTimeout(function() {
            if (locationMsg.parentNode) {
              locationMsg.style.animation = 'slideIn 0.3s ease-out reverse';
              setTimeout(function() {
                if (locationMsg.parentNode) locationMsg.parentNode.removeChild(locationMsg);
              }, 300);
            }
          }, delay);
    };
    
    // Evento per il pulsante Salta
    locationMsg.querySelector('.bo-location-skip').addEventListener('click', function(){
        removeLocationMsg();
    });

    navigator.geolocation.getCurrentPosition(function(pos){
      // Successo
      state.userLocation = {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude
      };
      
      // Aggiorna UI del popup
      locationMsg.querySelector('.bo-location-icon').textContent = '✅';
      locationMsg.querySelector('.bo-location-text').textContent = 'Posizione trovata!';
      locationMsg.querySelector('.bo-location-subtext').textContent = 'Caricamento distributori vicini...';
      
      // Centra mappa
      if (elements.map) {
        elements.map.setView([state.userLocation.lat, state.userLocation.lng], 13);
      }
      
      // Aggiorna filtri e avvia ricerca
      state.currentFilters.location = 'La mia posizione';
      if (elements.locationInput) {
        elements.locationInput.value = 'La mia posizione';
      }
      handleSearch();
      
      removeLocationMsg(2000);
      
    }, function(error){
      // Errore
      console.log('Geolocation error:', error);
      
      // Salva il rifiuto
      if (error.code === error.PERMISSION_DENIED) {
        try {
          localStorage.setItem('bo_location_denied', 'true');
        } catch(e) {}
      }
      
      // Aggiorna UI del popup
      locationMsg.querySelector('.bo-location-icon').textContent = '❌';
      locationMsg.querySelector('.bo-location-text').textContent = 'Posizione non disponibile';
      locationMsg.querySelector('.bo-location-subtext').textContent = 'Usa i filtri per cercare manualmente';
      locationMsg.style.borderColor = '#ef4444';
      
      removeLocationMsg(3000);
      
    }, { 
      enableHighAccuracy: true, 
      timeout: 10000,
      maximumAge: 300000 
    });
  }

  // Mostra/nascondi loading
  function showLoading(show) {
    const btn = elements.searchBtn;
    if (btn) {
      btn.disabled = show;
      btn.textContent = show ? 'Ricerca...' : 'Cerca';
    }
  }

  // Inizializza quando il DOM è pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();